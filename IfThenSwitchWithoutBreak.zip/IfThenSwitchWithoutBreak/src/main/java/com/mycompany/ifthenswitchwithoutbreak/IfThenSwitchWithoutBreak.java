/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ifthenswitchwithoutbreak;

/**
 *
 * @author Alvinno Ghany P
 */
public class IfThenSwitchWithoutBreak {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
