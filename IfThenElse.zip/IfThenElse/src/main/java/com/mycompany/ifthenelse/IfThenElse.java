/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ifthenelse;

/**
 *
 * @author Alvinno Ghany P
 */
public class IfThenElse {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
